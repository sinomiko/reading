
simple perl scripts that performs stylistic checking of C/C++ source code.

They are not intended to be 'released' as extra checks. I will just use them
to check the Cppcheck source code.

feel free to try them.

feel free to add additional scripts.


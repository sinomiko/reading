#warning "xf86vmstr.h is obsolete and may be removed in the future."
#warning "include <X11/extensions/xf86vmproto.h> for the protocol defines."
#include <X11/extensions/xf86vmproto.h>
